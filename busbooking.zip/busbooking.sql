/*
SQLyog Community v11.52 (64 bit)
MySQL - 5.7.12-log : Database - busbooking
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`busbooking` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `busbooking`;

/*Table structure for table `bus` */

DROP TABLE IF EXISTS `bus`;

CREATE TABLE `bus` (
  `busId` int(11) NOT NULL,
  `routeId` int(11) NOT NULL,
  `driverName` varchar(50) NOT NULL,
  `driverContactNo` int(10) DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `monitorName` varchar(50) NOT NULL,
  `monitorContactNo` int(10) NOT NULL,
  `availableSeat` int(11) NOT NULL,
  `avaibilityFlag` int(1) NOT NULL,
  PRIMARY KEY (`busId`),
  KEY `routeId` (`routeId`),
  CONSTRAINT `routeId` FOREIGN KEY (`routeId`) REFERENCES `route` (`routeId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bus` */

/*Table structure for table `buspass` */

DROP TABLE IF EXISTS `buspass`;

CREATE TABLE `buspass` (
  `passId` int(11) NOT NULL AUTO_INCREMENT,
  `staffId` int(11) NOT NULL,
  `routeId` int(11) NOT NULL,
  `passType` varchar(50) NOT NULL,
  `cost` int(11) NOT NULL,
  `passStartDate` date NOT NULL,
  `passEndDate` date NOT NULL,
  `passStatus` int(1) NOT NULL,
  PRIMARY KEY (`passId`),
  KEY `staffId` (`staffId`),
  KEY `routeId` (`routeId`),
  CONSTRAINT `buspass_ibfk_1` FOREIGN KEY (`staffId`) REFERENCES `user` (`staffId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `buspass_ibfk_2` FOREIGN KEY (`routeId`) REFERENCES `route` (`routeId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `buspass` */

/*Table structure for table `cost` */

DROP TABLE IF EXISTS `cost`;

CREATE TABLE `cost` (
  `costId` int(11) NOT NULL,
  `startPoint` varchar(50) NOT NULL,
  `endPoint` varchar(50) NOT NULL,
  `cost` int(11) NOT NULL,
  PRIMARY KEY (`costId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `cost` */

/*Table structure for table `route` */

DROP TABLE IF EXISTS `route`;

CREATE TABLE `route` (
  `routeId` int(11) NOT NULL,
  `staringPoint` varchar(50) NOT NULL,
  `startTime` datetime NOT NULL,
  `droppingPoint` varchar(50) NOT NULL,
  `dropTime` datetime DEFAULT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`routeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `route` */

/*Table structure for table `stafflogin` */

DROP TABLE IF EXISTS `stafflogin`;

CREATE TABLE `stafflogin` (
  `staffId` int(11) NOT NULL,
  `logInTime` datetime NOT NULL,
  `logOutTime` datetime NOT NULL,
  KEY `staffId` (`staffId`),
  CONSTRAINT `staffId` FOREIGN KEY (`staffId`) REFERENCES `user` (`staffId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `stafflogin` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `staffId` int(11) NOT NULL,
  `staffName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contactNo` int(10) DEFAULT NULL,
  `busId` int(11) NOT NULL,
  `routeId` int(11) NOT NULL,
  `costId` int(11) NOT NULL,
  PRIMARY KEY (`staffId`),
  KEY `busId` (`busId`),
  KEY `routeId` (`routeId`),
  KEY `costId` (`costId`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`busId`) REFERENCES `bus` (`busId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_ibfk_2` FOREIGN KEY (`routeId`) REFERENCES `route` (`routeId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_ibfk_3` FOREIGN KEY (`costId`) REFERENCES `cost` (`costId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
